package com.instabus.exception;

public class AdminAlreadyExistException extends RuntimeException {

	public AdminAlreadyExistException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AdminAlreadyExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
}
